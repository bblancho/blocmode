<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     3.0.0
 * @author      Zootemplate
 * @link        http://www.zootemplate.com
 * @copyright   Copyright (c) 2015 Zootemplate
 * @license     GPL v2
 * Allow override file in theme
 */
//require_once RIT_PLUGIN_INC_PATH . 'post-types/banner.php';
//require_once RIT_PLUGIN_INC_PATH . 'post-types/cause.php';
//require_once RIT_PLUGIN_INC_PATH . 'post-types/member.php';
//require_once RIT_PLUGIN_INC_PATH . 'post-types/portfolio.php';
require_once RIT_PLUGIN_INC_PATH . 'post-types/testimonial.php';
//require_once RIT_PLUGIN_INC_PATH . 'post-types/transaction.php';
