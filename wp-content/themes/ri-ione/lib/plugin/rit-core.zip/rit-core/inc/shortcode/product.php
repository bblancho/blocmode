<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     2.3.0
 * @author      Zootemplate
 * @link        http://www.zootemplate.com
 * @copyright   Copyright (c) 2015 Zootemplate
 * @license     GPL v2
 */
if (!function_exists('rit_shortcode_products')) {
    function rit_shortcode_products($atts, $content)
    {

        if (class_exists('WooCommerce')) {
            $product_categories = get_categories(
                array(
                    'taxonomy' => 'product_cat',
                )
            );
            $product_cats = array();
            $product_cats_all = '';
            if (count($product_categories) > 0) {

                foreach ($product_categories as $value) {
                    $product_cats[$value->name] = $value->slug;
                }
                $product_cats_all = implode(',', $product_cats);
            }


            $product_tags = get_terms('product_tag');
            $product_tags_arr = array();
            $product_tags_all = '';
            if (count($product_tags) > 0) {

                foreach ($product_tags as $value) {
                    $product_tags_arr[$value->name] = $value->slug;
                }
                $product_tags_all = implode(',', $product_tags_arr);
            }


            $attributes_arr = array();
            $attributes_arr_all = '';
            if (function_exists('wc_get_attribute_taxonomies')) {
                $product_attribute_taxonomies = wc_get_attribute_taxonomies();
                if (count($product_attribute_taxonomies) > 0) {

                    foreach ($product_attribute_taxonomies as $value) {
                        $attributes_arr[$value->attribute_label] = $value->attribute_name;
                    }
                    $attributes_arr_all = implode(',', $attributes_arr);
                }
            }

            $atts = shortcode_atts(array(
                'title' => '',
                'post_type' => 'product',
                'column' => '3',
                'col_width' => '170',
                'posts_per_page' => 4,
                'loadmore' => '',
                'products_type' => 'products_carousel',
                'products_img_size' => 'shop_thumbnail',
                'paged' => 1,
                'ignore_sticky_posts' => 1,
                'show' => '',
                'show_nav' => '',
                'show_pag' => '',
                'orderby' => 'date',
                'element_custom_class' => '',
                'padding_bottom_module' => '50px',
                'filter_categories' => $product_cats_all,
                'filter_tags' => $product_tags_all,
                'filter_attributes' => $attributes_arr_all,
                'show_filter' => 0,
                'show_featured_filter' => 0,
                'show_price_filter' => 0,
                'price_filter_level' => 5,
                'price_filter_range' => 100,
            ), $atts);


            $meta_query = WC()->query->get_meta_query();


            $wc_attr = array(
                'post_type' => 'product',
                'posts_per_page' => $atts['posts_per_page'],
                'paged' => $atts['paged'],
                'orderby' => $atts['orderby'],
                'ignore_sticky_posts' => $atts['ignore_sticky_posts'],
            );
            if ($atts['show'] == 'featured') {
                $meta_query[] = array(
                    'key' => '_featured',
                    'value' => 'yes'
                );
                $wc_attr['meta_query'] = $meta_query;
            } elseif ($atts['show'] == 'onsale') {

                $product_ids_on_sale = wc_get_product_ids_on_sale();

                $wc_attr['post__in'] = $product_ids_on_sale;

                $wc_attr['meta_query'] = $meta_query;

            } elseif ($atts['show'] == 'best-selling') {

                $wc_attr['meta_key'] = 'total_sales';

                $wc_attr['meta_query'] = $meta_query;

            } elseif ($atts['show'] == 'latest') {

                $wc_attr['orderby'] = 'date';

                $wc_attr['order'] = 'DESC';

            } elseif ($atts['show'] == 'toprate') {

                add_filter('posts_clauses', array('WC_Shortcodes', 'order_by_rating_post_clauses'));

            } elseif ($atts['show'] == 'price') {

                $wc_attr['orderby'] = "meta_value_num {$wpdb->posts}.ID";
                $wc_attr['order'] = 'ASC';
                $wc_attr['meta_key'] = '_price';

            } elseif ($atts['show'] == 'price-desc') {
                $wc_attr['orderby'] = "meta_value_num {$wpdb->posts}.ID";
                $wc_attr['order'] = 'DESC';
                $wc_attr['meta_key'] = '_price';

            }
            if ($atts['filter_categories'] != $product_cats_all && $atts['filter_categories'] != '') {
                $wc_attr['product_cat'] = $atts['filter_categories'];

            }
            $atts['wc_attr'] = $wc_attr;
            return rit_get_template_part('shortcode', 'product', array('atts' => $atts));
        }
        return null;

    }
}
add_shortcode('rit_products', 'rit_shortcode_products');

add_action('vc_before_init', 'rit_product_integrate_vc');

if (!function_exists('rit_product_integrate_vc')) {
    function rit_product_integrate_vc()
    {
        if (class_exists('WooCommerce')) {
            $product_categories = get_categories(
                array(
                    'taxonomy' => 'product_cat',
                )
            );
            $product_cats = array();
            $product_cats_all = '';
            if (count($product_categories) > 0) {

                foreach ($product_categories as $value) {
                    $product_cats[$value->name] = $value->slug;
                }
                $product_cats_all = implode(',', $product_cats);
            }


            $product_tags = get_terms('product_tag');
            $product_tags_arr = array();
            $product_tags_all = '';
            if (count($product_tags) > 0) {

                foreach ($product_tags as $value) {
                    $product_tags_arr[$value->name] = $value->slug;
                }
                $product_tags_all = implode(',', $product_tags_arr);
            }


            $attributes_arr = array();
            $attributes_arr_all = '';
            if (function_exists('wc_get_attribute_taxonomies')) {
                $product_attribute_taxonomies = wc_get_attribute_taxonomies();
                if (count($product_attribute_taxonomies) > 0) {

                    foreach ($product_attribute_taxonomies as $value) {
                        $attributes_arr[$value->attribute_label] = $value->attribute_name;
                    }
                    $attributes_arr_all = implode(',', $attributes_arr);
                }
            }


            vc_map(
                array(
                    'name' => esc_html__('RIT Products', 'rit-core-language'),
                    'base' => 'rit_products',
                    'icon' => 'icon-rit',
                    'category' => esc_html__('CleverSoft', 'rit-core-language'),
                    'description' => esc_html__('Show multiple products by ID or SKU.', 'rit-core-language'),
                    'params' => array(
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Title', 'rit-core-language'),
                            'value' => '',
                            'param_name' => 'title',
                            'description' => esc_html__('Enter text used as shortcode title (Note: located above content element)', 'rit-core-language'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Image size', 'rit-core-language'),
                            'group' => esc_html__('Layout', 'rit-core-language'),
                            'value' => array(
                                esc_html__('Thumbnail', 'rit-core-language') => 'shop_thumbnail',
                                esc_html__('Catalog Images', 'rit-core-language') => 'shop_catalog',
                                esc_html__('Single Product Image', 'rit-core-language') => 'shop_single'
                            ),
                            'param_name' => 'products_img_size',
                            'description' => esc_html__('Select image size follow size in woocommerce product image size', 'rit-core-language'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Layout type', 'rit-core-language'),
                            'group' => esc_html__('Layout', 'rit-core-language'),
                            'value' => array(
                                esc_html__('Carousel', 'rit-core-language') => 'products_carousel',
                                esc_html__('Grid', 'rit-core-language') => 'products_grid',
                                esc_html__('List', 'rit-core-language') => 'products_list'
                            ),
                            'param_name' => 'products_type',
                            'description' => esc_html__('Select layout type for display product', 'rit-core-language'),
                        ),
                        array(
                            'type' => 'textfield',
                            'group' => esc_html__('Layout', 'rit-core-language'),
                            'heading' => esc_html__('Column width', 'rit-core-language'),
                            'std' => '170',
                            "dependency" => Array('element' => 'products_type', 'value' => array('products_grid')),
                            'param_name' => 'col_width',
                            'description' => esc_html__('Width of one column.', 'rit-core-language'),
                        ),
                        array(
                            'type' => 'textfield',
                            'group' => esc_html__('Layout', 'rit-core-language'),
                            'heading' => esc_html__('Columns number', 'rit-core-language'),
                            'std' => '3',
                            "dependency" => Array('element' => 'products_type', 'value' => array('products_carousel')),
                            'param_name' => 'column',
                            'description' => esc_html__('Display product with the number of columns, accept only number.', 'rit-core-language'),
                        ),
                        array(
                            'type' => 'checkbox',
                            'heading' => esc_html__('Show carousel pagination', 'rit-core-language'),
                            'param_name' => 'show_pag',
                            'std' => '',
                            'group' => esc_html__('Layout', 'rit-core-language'),
                            "dependency" => Array('element' => 'products_type', 'value' => array('products_carousel')),
                            'value' => array(esc_html__('Yes', 'rit-core-language') => '1'),
                        ),
                        array(
                            'type' => 'checkbox',
                            'heading' => esc_html__('Show carousel navigation', 'rit-core-language'),
                            'param_name' => 'show_nav',
                            'std' => '',
                            'group' => esc_html__('Layout', 'rit-core-language'),
                            "dependency" => Array('element' => 'products_type', 'value' => array('products_carousel')),
                            'value' => array(esc_html__('Yes', 'rit-core-language') => '1'),
                        ),
                        array(
                            "type" => "rit_product_categories",
                            "heading" => esc_html__("Categories", 'rit-core-language'),
                            "param_name" => "filter_categories",
                            "std" => $product_cats_all,
                            "value" => $product_cats,
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Asset type', 'rit-core-language'),
                            'value' => array(
                                esc_html__('All', 'rit-core-language') => '',
                                esc_html__('Featured product', 'rit-core-language') => 'featured',
                                esc_html__('Onsale product', 'rit-core-language') => 'onsale',
                                esc_html__('Best Selling', 'rit-core-language') => 'best-selling',
                                esc_html__('Latest product', 'rit-core-language') => 'latest',
                                esc_html__('Top rate product', 'rit-core-language') => 'toprate ',
                                esc_html__('Sort by price: low to high', 'rit-core-language') => 'price',
                                esc_html__('Sort by price: high to low', 'rit-core-language') => 'price-desc',
                            ),
                            'std' => '',
                            'param_name' => 'show',
                            'description' => esc_html__('Select asset type of products', 'rit-core-language'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Order by', 'rit-core-language'),
                            'value' => array(
                                esc_html__('Date', 'rit-core-language') => 'date',
                                esc_html__('Menu order', 'rit-core-language') => 'menu_order',
                                esc_html__('Title', 'rit-core-language') => 'title',
                            ),
                            'std' => 'date',
                            'param_name' => 'orderby',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Number of product', 'rit-core-language'),
                            'value' => 6,
                            'param_name' => 'posts_per_page',
                            'description' => esc_html__('Number of product showing', 'rit-core-language'),
                        ),
                        array(
                            "type" => "dropdown",
                            "heading" => esc_html__("Ignore sticky posts", 'rit-core-language'),
                            "param_name" => "ignore_sticky_posts",
                            'std' => 1,
                            "value" => array(
                                esc_html__('No', 'rit-core-language') => 0,
                                esc_html__('Yes', 'rit-core-language') => 1,
                            ),
                        ),
                        array(
                            'type' => 'checkbox',
                            'heading' => esc_html__('Enable Load more', 'rit-core-language'),
                            'param_name' => 'loadmore',
                            'std' => '',
                            'value' => array(esc_html__('Yes', 'rit-core-language') => '1'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Custom Class', 'rit-core-language'),
                            'value' => '',
                            'param_name' => 'element_custom_class',
                            'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'rit-core-language'),
                        ),
                        array(
                            "type" => "dropdown",
                            "heading" => esc_html__("Show Filter", 'rit-core-language'),
                            "param_name" => "show_filter",
                            "dependency" => Array('element' => 'products_type', 'value' => array('products_grid')),
                            'group' => esc_html__('Filter', 'rit-core-language'),
                            'std' => 0,
                            "value" => array(
                                esc_html__('No', 'rit-core-language') => 0,
                                esc_html__('Yes', 'rit-core-language') => 1,
                            ),
                        ),
                        array(
                            "type" => "dropdown",
                            "heading" => esc_html__("Show Featured, Onsale, Best Selling, Latest product filter", 'rit-core-language'),
                            "param_name" => "show_featured_filter",
                            'std' => '0',
                            'group' => esc_html__('Filter', 'rit-core-language'),
                            "dependency" => Array('element' => 'show_filter', 'value' => array('1')),
                            "value" => array(
                                esc_html__('No', 'rit-core-language') => 0,
                                esc_html__('Yes', 'rit-core-language') => 1,
                            ),
                        ),
                        array(
                            "type" => "rit_multi_select",
                            "heading" => esc_html__("Tags showing in the filter", 'rit-core-language'),
                            "param_name" => "filter_tags",
                            'group' => esc_html__('Filter', 'rit-core-language'),
                            "dependency" => Array('element' => 'show_filter', 'value' => array('1')),
                            "std" => $product_tags_all,
                            "value" => $product_tags_arr,
                        ),
                        array(
                            "type" => "rit_multi_select",
                            "heading" => esc_html__("Product attributes showing in the filter", 'rit-core-language'),
                            "param_name" => "filter_attributes",
                            'group' => esc_html__('Filter', 'rit-core-language'),
                            "dependency" => Array('element' => 'show_filter', 'value' => array('1')),
                            "std" => $attributes_arr_all,
                            "value" => $attributes_arr,
                        ),
                        array(
                            "type" => "dropdown",
                            "heading" => esc_html__("Show Price Filter", 'rit-core-language'),
                            "param_name" => "show_price_filter",
                            'group' => esc_html__('Filter', 'rit-core-language'),
                            "std" => 0,
                            "dependency" => Array('element' => 'show_filter', 'value' => array('1')),
                            "value" => array(
                                esc_html__('No', 'rit-core-language') => 0,
                                esc_html__('Yes', 'rit-core-language') => 1,
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Number of price levels', 'rit-core-language'),
                            'value' => '5',
                            'std' => '5',
                            'group' => esc_html__('Filter', 'rit-core-language'),
                            'param_name' => 'price_filter_level',
                            "dependency" => Array('element' => 'show_price_filter', 'value' => array('1')),
                            'description' => esc_html__('Number of price levels showing in the filter', 'rit-core-language'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Filter range', 'rit-core-language'),
                            'std' => '100',
                            'value' => '100',
                            'group' => esc_html__('Filter', 'rit-core-language'),
                            'param_name' => 'price_filter_range',
                            "dependency" => Array('element' => 'show_price_filter', 'value' => array('1')),
                            'description' => esc_html__('Range of price filter. Example range equal 100 => price filter are "0$ to 100$", "100$ to 200$"', 'rit-core-language'),
                        ),
                    )
                )
            );
        }
    }
}