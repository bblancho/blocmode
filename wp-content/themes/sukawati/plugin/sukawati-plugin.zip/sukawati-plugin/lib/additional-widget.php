<?php

define('JEG_WIDGET_TEMPLATE_PATH', SUKAWATI_PLUGIN_DIR . '/lib/widget-template/');

/** base class of widget **/
abstract class Sukawati_Widget extends WP_Widget
{
    protected $jtemplate;
    protected $fields;

    public function __construct($id_base = false, $name, $widget_options = array(), $control_options = array())
    {
        parent::__construct( $id_base,$name , $widget_options , $control_options );
        $this->jtemplate = new JTemplate(JEG_WIDGET_TEMPLATE_PATH, '.php');
    }

    public function render_form($fields, $instance) {

        foreach ($fields as $key => $field) :

            //** type text widget input **/
            if($field['type'] == 'type-text') {
                $this->jtemplate->render('type-text', array(
                    'title'		=> $field['title'] ,
                    'desc'		=> $field['desc'] ,
                    'fieldid'	=> $this->get_field_id( $key ) ,
                    'fieldname'	=> $this->get_field_name( $key ) ,
                    'value'		=> isset($instance[$key]) ? $instance[$key] : ''
                ), true);
            }

            if($field['type'] == 'type-textarea') {
                $this->jtemplate->render('type-textarea', array(
                    'title'		=> $field['title'] ,
                    'desc'		=> $field['desc'] ,
                    'fieldid'	=> $this->get_field_id( $key ) ,
                    'fieldname'	=> $this->get_field_name( $key ) ,
                    'value'		=> isset($instance[$key]) ? $instance[$key] : ''
                ), true);
            }

            if($field['type'] == 'type-checkbox') {
                $this->jtemplate->render('type-checkbox', array(
                    'title'     => $field['title'] ,
                    'desc'      => $field['desc'] ,
                    'fieldid'   => $this->get_field_id( $key ) ,
                    'fieldname' => $this->get_field_name( $key ) ,
                    'value'     => isset($instance[$key]) ? $instance[$key] : ''
                ), true);
            }

            if($field['type'] == 'type-select') {
                $this->jtemplate->render('type-select', array(
                    'title'     => $field['title'] ,
                    'desc'      => $field['desc'] ,
                    'options'    => $field['options'],
                    'fieldid'   => $this->get_field_id( $key ) ,
                    'fieldname' => $this->get_field_name( $key ) ,
                    'value'     => isset($instance[$key]) ? $instance[$key] : ''
                ), true);
            }

        endforeach;
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();

        foreach ($this->fields as $key => $field) :
            // $instance[$key] = strip_tags( $new_instance[$key] );
            $instance[$key] = $new_instance[$key];
        endforeach;

        return $instance;
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $this->render_form($this->fields, $instance);
    }


    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        extract( $args );
        $title = apply_filters( 'widget_title', $instance['title'] );

        echo $args['before_widget'];
        if ( ! empty( $title ) )
            echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        $this->jtemplate->render( $this->get_widget_template() , $instance, true);

        echo $args['after_widget'];
    }

    abstract protected function get_widget_template();
}

/** Register widget **/
function sukawati_register_widget () {
    register_widget("sukawati_facebook_fans_widget");
    register_widget("sukawati_ads_widget");
    register_widget("sukawati_about_me");
    register_widget("sukawati_last_post");
    register_widget("sukawati_social_widget");
    register_widget("sukawati_category_slider");
    register_widget("sukawati_social_block_widget");
}

add_action( 'widgets_init', 'sukawati_register_widget' );
/** Register widget **/



/**
 * Adds Facebook Fans Widget.
 */
class Sukawati_Category_Slider extends Sukawati_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {

        $categories = get_categories();
        $category = array();
        foreach($categories as $value) {
            $category[$value->term_id] = $value->name;
        }

        $this->fields = array (
            'title'     => array(
                'title'     => 'Title',
                'desc'      => 'Title on Widget header',
                'type'      => 'type-text'
            ),
            'category'   => array(
                'title'     => 'Category',
                'desc'      => 'choose category',
                'options'    => $category,
                'type'      => 'type-select'
            ),
        );

        parent::__construct(
            'sukawati_category_slider', // Base ID
            'Sukawati: Category Slider', // Name
            array( 'description' =>  'Category slider for Sukawati' , ) // Args
        );
    }

    public function get_widget_template () {
        return 'category-slider-widget';
    }

}

/**
 * Adds Facebook Fans Widget.
 */
class Sukawati_Facebook_Fans_Widget extends Sukawati_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {

        $this->fields = array (
            'title'     => array(
                'title'     => 'Title',
                'desc'      => 'Title on Widget header',
                'type'      => 'type-text'
            ),
            'facebookurl'   => array(
                'title'     => 'Facebook Page URL',
                'desc'      => 'Your widget page url like : http://www.facebook.com/jegbagusbarbershop',
                'type'      => 'type-text'
            )
        );

        parent::__construct(
            'sukawati_facebook_fans_widget', // Base ID
            'Sukawati: Facebook Fans Widget', // Name
            array( 'description' =>  'Sidebar Facebook fans widget for Sukawati' , ) // Args
        );
    }

    public function get_widget_template () {
        return 'facebook-widget';
    }

}


/**
 * Adds About Me Widget.
 */
class Sukawati_About_Me extends Sukawati_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {

        $this->fields = array (
            'title'     => array(
                'title'     => 'Title',
                'desc'      => 'Title on Widget header',
                'type'      => 'type-text'
            ),
            'aboutimg'   => array(
                'title'     => 'About Image URL',
                'desc'      => 'put your image URL right here',
                'type'      => 'type-text'
            ),
            'aboutdesc'   => array(
                'title'     => 'About Description',
                'desc'      => 'You may use standard HTML tags and attributes.',
                'type'      => 'type-textarea'
            ),
            'textcenter'   => array(
                'title'     => 'Centering Text',
                'desc'      => 'Set text align center',
                'type'      => 'type-checkbox'
            )
        );

        parent::__construct(
            'sukawati_about_me', // Base ID
            'Sukawati: About Me', // Name
            array( 'description' =>  'About me box for Sukawati' , ) // Args
        );
    }

    public function get_widget_template () {
        return 'about-us-widget';
    }

}


/**
 * Adds Last Post Widget
 */
class Sukawati_Last_Post extends Sukawati_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {

        $this->fields = array (
            'title'     => array(
                'title'     => 'Title',
                'desc'      => 'Title on Widget header',
                'type'      => 'type-text'
            ),
            'lastnumber'   => array(
                'title'     => 'Number of latest post',
                'desc'      => 'default latest post : 4',
                'type'      => 'type-text'
            ),
            'disableoverlay'   => array(
                'title'     => 'Disable Title Overlay',
                'desc'      => '',
                'type'      => 'type-checkbox'
            )
        );

        parent::__construct(
            'sukawati_last_post', // Base ID
            'Sukawati: Latest post', // Name
            array( 'description' =>  'latest post Sukawati' , ) // Args
        );
    }

    public function get_widget_template () {
        return 'last-post';
    }

}



/**
 * Adds Facebook Fans Widget.
 */
class Sukawati_Ads_Widget extends Sukawati_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {

        $this->fields = array (
            'title'     => array(
                'title'     =>  'Title',
                'desc'      => 'Title on Widget header',
                'type'      => 'type-text'
            ),
            'adsimage'  => array(
                'title'     =>  'Your ads image' ,
                'desc'      => 'Your ads image url',
                'type'      => 'type-text'
            ),
            'adsurl'    => array(
                'title'     =>  'URL of your ads',
                'desc'      => 'where user will be redirected when they click your ads',
                'type'      => 'type-text'
            )
        );

        parent::__construct (
            'sukawati_ads_widget', // Base ID
            'Sukawati: Ads Widget', // Name
            array( 'description' =>  'Add banner to your sidebar' ) // Args
        );
    }

    public function get_widget_template () {
        return 'ads-widget';
    }
}


/**
 * Adds Social Widget
 */
class Sukawati_Social_Widget extends Sukawati_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {

        $this->fields = array (
            'title'     => array(
                'title'     => 'Title',
                'desc'      => 'Title on Widget header',
                'type'      => 'type-text'
            ),
            'textcenter'   => array(
                'title'     => 'Align Center',
                'desc'      => 'Centering icon position',
                'type'      => 'type-checkbox'
            ),
            'social_facebook'   => array(
                'title'     => 'Facebook',
                'desc'      => 'ex: http://facebook.com/username',
                'type'      => 'type-text'
            ),
            'social_twitter'    => array(
                'title'     => 'Twitter',
                'desc'      => 'ex: http://twitter.com/username',
                'type'      => 'type-text'
            ),
            'social_linkedin'   => array(
                'title'     => 'Linkedin',
                'desc'      => 'ex: http://www.linkedin.com/in/yourname',
                'type'      => 'type-text'
            ),
            'social_googleplus' => array(
                'title'     => 'Google+',
                'desc'      => 'ex: https://plus.google.com/username',
                'type'      => 'type-text'
            ),
            'social_pinterest'  => array(
                'title'     => 'Pinterest',
                'desc'      => 'ex: https://www.pinterest.com/username',
                'type'      => 'type-text'
            ),
            'social_behance'    => array(
                'title'     => 'Behance',
                'desc'      => 'ex: https://www.behance.net/username',
                'type'      => 'type-text'
            ),
            'social_github' => array(
                'title'     => 'Github',
                'desc'      => 'ex: https://github.com/username',
                'type'      => 'type-text'
            ),
            'social_flickr' => array(
                'title'     => 'Flickr',
                'desc'      => 'ex: https://www.flickr.com/photos/username',
                'type'      => 'type-text'
            ),
            'social_tumblr' => array(
                'title'     => 'Tumblr',
                'desc'      => 'ex: http://yourblog.tumblr.com',
                'type'      => 'type-text'
            ),
            'social_dribbble'   => array(
                'title'     => 'Dribbble',
                'desc'      => 'ex: https://dribbble.com/username',
                'type'      => 'type-text'
            ),
            'social_soundcloud' => array(
                'title'     => 'Soundcloud',
                'desc'      => 'ex: https://soundcloud.com/username',
                'type'      => 'type-text'
            ),
            'social_instagram'  => array(
                'title'     => 'Instagram',
                'desc'      => 'ex: https://instagram.com/username',
                'type'      => 'type-text'
            ),
            'social_vimeo'  => array(
                'title'     => 'Vimeo',
                'desc'      => 'ex: https://vimeo.com/username',
                'type'      => 'type-text'
            ),
            'social_youtube'    => array(
                'title'     => 'Youtube',
                'desc'      => 'ex: https://www.youtube.com/user/username',
                'type'      => 'type-text'
            ),
        );

        parent::__construct(
            'sukawati_social_widget', // Base ID
            'Sukawati: Social Widget', // Name
            array( 'description' =>  'Add social media icons to your widget area Sukawati' , ) // Args
        );
    }

    public function get_widget_template () {
        return 'social-widget';
    }

}



/**
 * Adds Social Widget
 */
class Sukawati_Social_Block_Widget extends Sukawati_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {

        $this->fields = array (
            'title'     => array(
                'title'     => 'Title',
                'desc'      => 'Title on Widget header',
                'type'      => 'type-text'
            ),
            'social_facebook'   => array(
                'title'     => 'Facebook',
                'desc'      => 'ex: http://facebook.com/username',
                'type'      => 'type-text'
            ),
            'social_twitter'    => array(
                'title'     => 'Twitter',
                'desc'      => 'ex: http://twitter.com/username',
                'type'      => 'type-text'
            ),
            'social_linkedin'   => array(
                'title'     => 'Linkedin',
                'desc'      => 'ex: http://www.linkedin.com/in/yourname',
                'type'      => 'type-text'
            ),
            'social_googleplus' => array(
                'title'     => 'Google+',
                'desc'      => 'ex: https://plus.google.com/username',
                'type'      => 'type-text'
            ),
            'social_pinterest'  => array(
                'title'     => 'Pinterest',
                'desc'      => 'ex: https://www.pinterest.com/username',
                'type'      => 'type-text'
            ),
            'social_behance'    => array(
                'title'     => 'Behance',
                'desc'      => 'ex: https://www.behance.net/username',
                'type'      => 'type-text'
            ),
            'social_github' => array(
                'title'     => 'Github',
                'desc'      => 'ex: https://github.com/username',
                'type'      => 'type-text'
            ),
            'social_flickr' => array(
                'title'     => 'Flickr',
                'desc'      => 'ex: https://www.flickr.com/photos/username',
                'type'      => 'type-text'
            ),
            'social_tumblr' => array(
                'title'     => 'Tumblr',
                'desc'      => 'ex: http://yourblog.tumblr.com',
                'type'      => 'type-text'
            ),
            'social_dribbble'   => array(
                'title'     => 'Dribbble',
                'desc'      => 'ex: https://dribbble.com/username',
                'type'      => 'type-text'
            ),
            'social_soundcloud' => array(
                'title'     => 'Soundcloud',
                'desc'      => 'ex: https://soundcloud.com/username',
                'type'      => 'type-text'
            ),
            'social_instagram'  => array(
                'title'     => 'Instagram',
                'desc'      => 'ex: https://instagram.com/username',
                'type'      => 'type-text'
            ),
            'social_vimeo'  => array(
                'title'     => 'Vimeo',
                'desc'      => 'ex: https://vimeo.com/username',
                'type'      => 'type-text'
            ),
            'social_youtube'    => array(
                'title'     => 'Youtube',
                'desc'      => 'ex: https://www.youtube.com/user/username',
                'type'      => 'type-text'
            ),
        );

        parent::__construct(
            'sukawati_social_block_widget', // Base ID
            'Sukawati: Social Block Widget', // Name
            array( 'description' =>  'Add social media icons to your widget area Sukawati' , ) // Args
        );
    }

    public function get_widget_template () {
        return 'social-block-widget';
    }

}