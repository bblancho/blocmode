<?php
$result = new WP_Query(array(
    'post_status' => 'publish',
    'posts_per_page' => 5,
    'orderby' => 'date',
    'order' => 'desc',
    'cat' => $category
));
?>
<div class="category-slider owl-carousel owl-theme">
<?php
if($result->have_posts()) {
    while ($result->have_posts()) {
        $result->the_post();
    ?>
        <div class="item">
            <div class="category-feature-holder clearfix">
                <?php the_post_thumbnail('sukawati-new-feature-2') ?>
            </div>

            <div class="category-wrapper">
                <div class="category-content">
                    <?php get_template_part( 'include/postmeta' ); ?>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                </div>
                <div class="category-nav">
                    <div class="nav-left"><i class="fa fa-angle-left"></i></div>
                    <div class="nav-right"><i class="fa fa-angle-right"></i></div>
                </div>
            </div>

        </div>
    <?php
    }
    wp_reset_postdata();
}
?>
</div>

<script type="text/javascript">
    (function ($) {
        $(document).ready(function() {
            var categoryslider = $(".category-slider");

            var slider = $(categoryslider).owlCarousel({
                loop:true,
                nav:false,
                dots: false,
                responsive:{
                    0:{
                        items:1
                    }
                },
                rtl: <?php echo esc_js( is_rtl() ? "true" : "false" ); ?>
            });

            $(".category-slider .nav-left").bind('click', function(){
                slider.trigger('prev.owl.carousel');
            });

            $(".category-slider .nav-right").bind('click', function(){
                slider.trigger('next.owl.carousel');
            });
        });
    })(jQuery);
</script>