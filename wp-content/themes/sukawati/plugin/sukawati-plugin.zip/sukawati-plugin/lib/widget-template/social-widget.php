<div class="jeg-social-widget <?php echo esc_attr( $textcenter ? 'text-center' : '' ); ?>">
    <ul>
        <?php if (isset($social_facebook) && !empty($social_facebook)): ?>
            <li><a href="<?php echo esc_attr( $social_facebook );?>" target="_blank" rel="nofollow" class="social-facebook"><i class="fa fa-facebook"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_twitter) && !empty($social_twitter)): ?>
            <li><a href="<?php echo esc_attr( $social_twitter );?>" target="_blank" rel="nofollow" class="social-twitter"><i class="fa fa-twitter"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_linkedin) && !empty($social_linkedin)): ?>
            <li><a href="<?php echo esc_attr( $social_linkedin );?>" target="_blank" rel="nofollow" class="social-linkedin"><i class="fa fa-linkedin"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_googleplus) && !empty($social_googleplus)): ?>
            <li><a href="<?php echo esc_attr( $social_googleplus );?>" target="_blank" rel="nofollow" class="social-googleplus"><i class="fa fa-google-plus"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_pinterest) && !empty($social_pinterest)): ?>
            <li><a href="<?php echo esc_attr( $social_pinterest );?>" target="_blank" rel="nofollow" class="social-pinterest"><i class="fa fa-pinterest"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_behance) && !empty($social_behance)): ?>
            <li><a href="<?php echo esc_attr( $social_behance );?>" target="_blank" rel="nofollow" class="social-behance"><i class="fa fa-behance"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_github) && !empty($social_github)): ?>
            <li><a href="<?php echo esc_attr( $social_github );?>" target="_blank" rel="nofollow" class="social-github"><i class="fa fa-github"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_flickr) && !empty($social_flickr)): ?>
            <li><a href="<?php echo esc_attr( $social_flickr );?>" target="_blank" rel="nofollow" class="social-flickr"><i class="fa fa-flickr"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_tumblr) && !empty($social_tumblr)): ?>
            <li><a href="<?php echo esc_attr( $social_tumblr );?>" target="_blank" rel="nofollow" class="social-tumblr"><i class="fa fa-tumblr"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_dribbble) && !empty($social_dribbble)): ?>
            <li><a href="<?php echo esc_attr( $social_dribbble );?>" target="_blank" rel="nofollow" class="social-dribbble"><i class="fa fa-dribbble"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_soundcloud) && !empty($social_soundcloud)): ?>
            <li><a href="<?php echo esc_attr( $social_soundcloud );?>" target="_blank" rel="nofollow" class="social-soundcloud"><i class="fa fa-soundcloud"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_instagram) && !empty($social_instagram)): ?>
            <li><a href="<?php echo esc_attr( $social_instagram );?>" target="_blank" rel="nofollow" class="social-instagram"><i class="fa fa-instagram"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_vimeo) && !empty($social_vimeo)): ?>
            <li><a href="<?php echo esc_attr( $social_vimeo );?>" target="_blank" rel="nofollow" class="social-vimeo"><i class="fa fa-vimeo-square"></i></a></li>
        <?php endif; ?>

        <?php if (isset($social_youtube) && !empty($social_youtube)): ?>
            <li><a href="<?php echo esc_attr( $social_youtube );?>" target="_blank" rel="nofollow" class="social-youtube"><i class="fa fa-youtube"></i></a></li>
        <?php endif; ?>
    </ul>
</div>