<?php $disableoverlay = isset($disableoverlay) ? "disableoverlay" : ""; ?>
<div class="latest-post <?php echo esc_html($disableoverlay); ?>">
    <ul>
<?php
    $number = empty ( $lastnumber ) ? 4 : $lastnumber ;
    $query = new WP_Query(array(
        'post_type'				=> "post",
        'orderby'				=> "date",
        'order'					=> "DESC",
        'posts_per_page'		=> $number
    ));

    $imagesize = 'medium';

    if($disableoverlay) {
        $imagesize = 'sukawati-lastest-small';
    }

    if ( $query->have_posts() ) {
        $i = 0;
        while ($query->have_posts()) {
            $query->the_post();
?>
    <li>
        <div class="latest-post-item">
            <?php if(has_post_thumbnail(get_the_ID())) { ?>
                <div class="feature-holder">
                    <a href="<?php echo get_permalink( get_the_ID() ); ?>"><?php echo get_the_post_thumbnail( get_the_ID(), $imagesize ) ?></a>
                </div>
            <?php } else { ?>
                <div class="feature-holder">
                    <a href="<?php echo get_permalink( get_the_ID() ); ?>"><img src="<?php echo get_template_directory_uri(). "/images/placeholder/300x200.png" ?>" alt="<?php the_title(); ?>"></a>
                </div>
            <?php } ?>
            <div class="feature-summary">
                <h3><a href="<?php echo get_permalink( get_the_ID() ); ?>"><?php the_title(); ?></a></h3>
                <span class="meta-date"><?php the_date(); ?></span>
            </div>
            <div class="clear"></div>
        </div>
    </li>
<?php
        }
    }
    wp_reset_postdata();
?>
    </ul>
</div>