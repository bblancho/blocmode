<div class="jeg-social-widget jeg-social-block-widget <?php echo esc_attr( $textcenter ? 'text-center' : '' ); ?>">
    <ul>
        <?php if (isset($social_facebook) && !empty($social_facebook)): ?>
            <li class="social-wrapper-facebook">
                <a href="<?php echo esc_attr( $social_facebook );?>" target="_blank" rel="nofollow" class="social-facebook">
                    <i class="fa fa-facebook"></i>
                    <span><?php esc_html_e('Facebook', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_twitter) && !empty($social_twitter)): ?>
            <li class="social-wrapper-twitter">
                <a href="<?php echo esc_attr( $social_twitter );?>" target="_blank" rel="nofollow" class="social-twitter">
                    <i class="fa fa-twitter"></i>
                    <span><?php esc_html_e('Twitter', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_linkedin) && !empty($social_linkedin)): ?>
            <li class="social-wrapper-linkedin">
                <a href="<?php echo esc_attr( $social_linkedin );?>" target="_blank" rel="nofollow" class="social-linkedin">
                    <i class="fa fa-linkedin"></i>
                    <span><?php esc_html_e('LinkedIn', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_googleplus) && !empty($social_googleplus)): ?>
            <li class="social-wrapper-googleplus">
                <a href="<?php echo esc_attr( $social_googleplus );?>" target="_blank" rel="nofollow" class="social-googleplus">
                    <i class="fa fa-google-plus"></i>
                    <span><?php esc_html_e('Google+', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_pinterest) && !empty($social_pinterest)): ?>
            <li class="social-wrapper-pinterest">
                <a href="<?php echo esc_attr( $social_pinterest );?>" target="_blank" rel="nofollow" class="social-pinterest">
                    <i class="fa fa-pinterest"></i>
                    <span><?php esc_html_e('Pinterest', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_behance) && !empty($social_behance)): ?>
            <li class="social-wrapper-behance">
                <a href="<?php echo esc_attr( $social_behance );?>" target="_blank" rel="nofollow" class="social-behance">
                    <i class="fa fa-behance"></i>
                    <span><?php esc_html_e('Behance', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_github) && !empty($social_github)): ?>
            <li class="social-wrapper-github">
                <a href="<?php echo esc_attr( $social_github );?>" target="_blank" rel="nofollow" class="social-github">
                    <i class="fa fa-github"></i>
                    <span><?php esc_html_e('Github', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_flickr) && !empty($social_flickr)): ?>
            <li class="social-wrapper-flickr">
                <a href="<?php echo esc_attr( $social_flickr );?>" target="_blank" rel="nofollow" class="social-flickr">
                    <i class="fa fa-flickr"></i>
                    <span><?php esc_html_e('Flickr', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_tumblr) && !empty($social_tumblr)): ?>
            <li class="social-wrapper-tumblr">
                <a href="<?php echo esc_attr( $social_tumblr );?>" target="_blank" rel="nofollow" class="social-tumblr">
                    <i class="fa fa-tumblr"></i>
                    <span><?php esc_html_e('Tumblr', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_dribbble) && !empty($social_dribbble)): ?>
            <li class="social-wrapper-dribbble">
                <a href="<?php echo esc_attr( $social_dribbble );?>" target="_blank" rel="nofollow" class="social-dribbble">
                    <i class="fa fa-dribbble"></i>
                    <span><?php esc_html_e('Dribbble', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_soundcloud) && !empty($social_soundcloud)): ?>
            <li class="social-wrapper-soundcloud">
                <a href="<?php echo esc_attr( $social_soundcloud );?>" target="_blank" rel="nofollow" class="social-soundcloud">
                    <i class="fa fa-soundcloud"></i>
                    <span><?php esc_html_e('Soundcloud', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_instagram) && !empty($social_instagram)): ?>
            <li class="social-wrapper-instagram">
                <a href="<?php echo esc_attr( $social_instagram );?>" target="_blank" rel="nofollow" class="social-instagram">
                    <i class="fa fa-instagram"></i>
                    <span><?php esc_html_e('Instagram', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_vimeo) && !empty($social_vimeo)): ?>
            <li class="social-wrapper-vimeo">
                <a href="<?php echo esc_attr( $social_vimeo );?>" target="_blank" rel="nofollow" class="social-vimeo">
                    <i class="fa fa-vimeo-square"></i>
                    <span><?php esc_html_e('Vimeo', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($social_youtube) && !empty($social_youtube)): ?>
            <li class="social-wrapper-youtube">
                <a href="<?php echo esc_attr( $social_youtube );?>" target="_blank" rel="nofollow" class="social-youtube">
                    <i class="fa fa-youtube"></i>
                    <span><?php esc_html_e('Youtube', 'sukawati-themes'); ?></span>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</div>