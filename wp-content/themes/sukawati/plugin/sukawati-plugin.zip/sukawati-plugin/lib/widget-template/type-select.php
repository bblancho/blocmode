<p>
    <label for="<?php echo esc_attr( $fieldid ); ?>"><?php echo esc_html( $title )  ?></label>
    <select class="widefat" id="<?php echo esc_attr( $fieldid ) ?>" name="<?php echo esc_attr( $fieldname ) ?>">
        <?php
            foreach($options as $key => $option) {
                $select = ( $value == $key ) ? "selected" : "";
                echo "<option value='$key' $select>$option</option>";
            }
        ?>
    </select>
    <i><?php echo strip_tags( $desc, '<strong><b><em><u><i><br><p>' ) ?></i>
</p>