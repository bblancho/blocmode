<div class="blog-fb-likebox">
    <div class="fb-page" data-href="<?php echo esc_url( $facebookurl ); ?>"
        data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"></div>
</div>