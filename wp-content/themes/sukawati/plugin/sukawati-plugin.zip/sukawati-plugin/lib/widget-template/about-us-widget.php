<div class="about-us-widget <?php echo esc_attr( $textcenter ? 'text-center' : '' ); ?>">
    <div class="about-image">
        <img src="<?php echo esc_url( $aboutimg ); ?>" alt="">
    </div>
    <div class="about-description">
        <?php echo wp_kses_post( $aboutdesc ); ?>
    </div>
</div>