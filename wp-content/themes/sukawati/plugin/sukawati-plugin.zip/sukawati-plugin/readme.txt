
== 1.0.1 ==
- initial release

== 1.0.2 ==
- fix issues with import content

== 1.0.3 ==
- fix failed import

== 1.0.4 ==
- improve font customizer
- Fix issues with warning on backend

== 1.0.5 ==
- fix minor advertisement issue

== 1.0.6 ==
- fix Category Slider on mobile issue
- fix mobile menu issue

== 1.0.7 ==
- fix show/hide social share on single post
- improve mobile styling

== 1.0.8 ==
- fix Pinterest share button
