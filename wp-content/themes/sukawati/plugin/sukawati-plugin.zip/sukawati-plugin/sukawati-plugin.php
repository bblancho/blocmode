<?php
/*
	Plugin Name: Sukawati Plugin
	Plugin URI: http://jegtheme.com/
	Description: Mandatory Plugin for Sukawati Theme
	Version: 1.0.8
	Author: Jegtheme
	Author URI: http://jegtheme.com
	License: GPL2
*/

defined( 'SUKAWATI_PLUGIN_VERSION' ) 	        or define( 'SUKAWATI_PLUGIN_VERSION', '1.0.8' );
defined( 'JEG_VERSION' ) 	                    or define( 'JEG_VERSION', '1.0.8' );
defined( 'SUKAWATI_PLUGIN_URL' ) 		        or define( 'SUKAWATI_PLUGIN_URL', plugins_url('sukawati-plugin'));
defined( 'SUKAWATI_PLUGIN_FILE' ) 		        or define( 'SUKAWATI_PLUGIN_FILE',  __FILE__ );
defined( 'SUKAWATI_PLUGIN_DIR' ) 		        or define( 'SUKAWATI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );


function sukawati_plugin_load() {
    if( defined('JEG_PLUGIN_VERSION') ) {
        require_once SUKAWATI_PLUGIN_DIR . '/lib/additional-widget.php';
    }
}
add_action('plugins_loaded', 'sukawati_plugin_load');

function sukawati_load_textdomain()
{
    $domain = 'sukawati-plugin';
    $lang_dir = dirname( plugin_basename( SUKAWATI_PLUGIN_FILE ) ) . '/lang/';

    // Traditional WordPress plugin locale filter
    $locale        = apply_filters( 'plugin_locale',  get_locale(), $domain );
    $mofile        = sprintf( '%1$s-%2$s.mo', $domain, $locale );

    // Setup paths to current locale file
    $mofile_local  = $lang_dir . $mofile;
    $mofile_global = WP_LANG_DIR . '/' . $domain . '/' . $mofile;


    if ( file_exists( $mofile_global ) ) {
        load_textdomain( $domain, $mofile_global );
    } elseif ( file_exists( $mofile_local ) ) {
        load_textdomain( $domain, $mofile_local );
    } else {
        load_plugin_textdomain( $domain, false, $lang_dir );
    }
}
add_action('init', 'sukawati_load_textdomain');